Si vous trouvez des bugs merci de me les signalez sur mon discord : Sirius#7667

pour utiliser le selfbot,
vous devez mettre votre token dans le config.json et mettre votre token dans les ""
si vous ne savez pas comment avoir votre token tapez sur youtube :
comment avoir son token discord

IMPORTANT VOUS DEVEZ EXTRAIRE LE NODE MODULES

vous devez aussi mettre votre prefix dans le config.json

vous devez installer node js sur votre PC pour utiliser le selfbot 

https://nodejs.org/en/ installer la version recommandée

